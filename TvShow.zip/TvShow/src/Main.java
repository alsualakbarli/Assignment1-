import entity.Movie;
import entity.TvShow;

public class Main {
    public static void main(String[] args) {
        Movie movie1 = new Movie("Tütək səsi", "Rasim Ocaqov", new String[]{"Isa Hüseynov"}, new String[]{"Akif Məhərrəmov", "Mihai Volontir", "Məmmədrza Şeyxzamanov", "Zemfira Sadıqova"}, 1975, 82);

        Movie movie2 = new Movie("Tütək səsi", "Rasim Ocaqov", new String[]{"Isa Hüseynov"}, new String[]{"Akif Məhərrəmov", "Mihai Volontir", "Məmmədrza Şeyxzamanov", "Zemfira Sadıqova"}, 1975, 82);
        Movie movie3 = new Movie("Tütək səsi", "Rasim Ocaqov", new String[]{"Isa Hüseynov"}, new String[]{"Akif Məhərrəmov", "Mihai Volontir", "Məmmədrza Şeyxzamanov", "Zemfira Sadıqova"}, 1975, 82);

        TvShow show1 = new TvShow("Untitled_Show", 2023, "Creator_of_show", new Movie[]{movie1, movie2, movie3});

        System.out.println(show1.getNumberOfEpisodes());
        System.out.println(show1);
    }
}
