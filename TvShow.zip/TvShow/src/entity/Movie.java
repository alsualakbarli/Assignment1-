package entity;

import entity.abstractEntity.MotionPicture;

public class Movie extends MotionPicture {
    private String director;
    private String[] screenWriters;
    private String[] starring;

    public Movie(String title, String director, String[] screenWriters, String[] starring, int year, int runningTime) {
        super(title, year, runningTime);
        this.director = director;
        this.screenWriters = screenWriters;
        this.starring = starring;
    }


    @Override
    public String toString() {
        return "Title: " + getTitle() + "\nDirector: " + director + "\nYear: " + getYear() + "\nRunning Time: " + getRunningTime();
    }
}
