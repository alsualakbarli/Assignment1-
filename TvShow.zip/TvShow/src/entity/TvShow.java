package entity;

import entity.abstractEntity.MotionPicture;

public class TvShow extends MotionPicture {
    private String creator;
    private Movie[] episodes;

    public TvShow(String title, int year, String creator, Movie[] episodes) {
        super(title, year, calculateRunningTime(episodes));
        this.creator = creator;
        this.episodes = episodes;
    }

    private static int calculateRunningTime(Movie[] episodes) {
        int totalRunningTime = 0;
        for (Movie episode : episodes) {
            totalRunningTime += episode.getRunningTime();
        }
        return totalRunningTime;
    }

    public int getNumberOfEpisodes() {
        return episodes.length;
    }

    @Override
    public String toString() {
        StringBuilder episodeList = new StringBuilder();
        for (Movie episode : episodes) {
            episodeList.append(episode.toString()).append("\n");
        }

        return "Title: " + getTitle() + "\nCreator: " + creator + "\nRunning Time: " + getRunningTime() + "\nNumber of Episodes: " + getNumberOfEpisodes() + "\nEpisodes:\n" + episodeList;
    }
}
