package entity.abstractEntity;

public abstract class MotionPicture {
    private String title;
    private int year;
    private int runningTime;

    public MotionPicture(String title, int year, int runningTime) {
        this.title = title;
        if (isValidYear(year)) {
            this.year = year;
        } else {
            System.out.println("Invalid year for " + title);
        }
        if (isValidRunningTime(runningTime)) {
            this.runningTime = runningTime;
        } else {
            System.out.println("Invalid running time for " + title);
        }
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        if (isValidYear(year)) {
            this.year = year;
        } else {
            System.out.println("Invalid year for " + title);
        }
    }

    public int getRunningTime() {
        return runningTime;
    }

    public void setRunningTime(int runningTime) {
        if (isValidRunningTime(runningTime)) {
            this.runningTime = runningTime;
        } else {
            System.out.println("Invalid running time for " + title);
        }
    }

    private boolean isValidYear(int year) {
        return year >= 1895 && year <= 2023;
    }

    private boolean isValidRunningTime(int runningTime) {
        return runningTime >= 0;
    }

    public abstract String toString();
}
